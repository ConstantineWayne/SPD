# -*- coding: utf-8 -*-

from torch.utils.data import Dataset
from .event_dataset import VoxelGridDataset
from skimage import io
from os.path import join
import numpy as np
from utils.util import first_element_greater_than, last_element_less_than
import random
import glob
import torch
import torch.nn.functional as f
import cv2


def apply_noise(img, noise_type=None, severity=1):
    """
    img: numpy RGB [H,W,3], uint8
    severity: 1~5
    """
    # 修正：包含所有支持的类型
    valid_types = ['gaussian']
    if noise_type is None or noise_type not in valid_types:
        return img

    # 先转换为 float 避免计算溢出
    img_float = img.astype(np.float32)

    if noise_type == 'gaussian':
        # 建议扩大 sigma 范围，5 在 RGB 空间里肉眼几乎看不见
        sigma_map = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50}
        sigma = sigma_map.get(severity, 25)
        noise = np.random.normal(0, sigma, img.shape)
        img_float = img_float + noise

    # 裁剪并转回 uint8
    return np.clip(img_float, 0, 255).astype(np.uint8)


class SequenceSynchronizedFramesEventsDataset(Dataset):

    def __init__(self, base_folder, event_folder, depth_folder='frames', frame_folder='rgb', flow_folder='flow',
                 semantic_folder='semantic/data/',
                 start_time=0.0, stop_time=0.0,
                 sequence_length=2, transform=None,
                 proba_pause_when_running=0.0, proba_pause_when_paused=0.0,
                 step_size=20,
                 clip_distance=100.0,
                 normalize=True,
                 scale_factor=1.0,
                 use_phased_arch=False,
                 every_x_rgb_frame=1,
                 baseline=False,
                 loss_composition=False,
                 reg_factor=3.7,
                 noise=None,
                 severity=None
                 ):
        assert (sequence_length > 0)
        assert (step_size > 0)
        assert (clip_distance > 0)
        self.L = sequence_length

        self.dataset = SynchronizedFramesEventsDataset(base_folder, event_folder, depth_folder, frame_folder,
                                                       flow_folder, semantic_folder, start_time, stop_time,
                                                       clip_distance, every_x_rgb_frame, transform,
                                                       normalize=normalize, use_phased_arch=use_phased_arch,
                                                       baseline=baseline, loss_composition=loss_composition,
                                                       reg_factor=reg_factor, noise=noise, severity=severity)

        self.event_dataset = self.dataset.event_dataset
        self.step_size = step_size
        self.every_x_rgb_frame = every_x_rgb_frame
        if self.L * self.every_x_rgb_frame >= self.dataset.length:
            self.length = 0
        else:
            self.length = ((self.dataset.length - self.L * self.every_x_rgb_frame) // self.step_size \
                           // self.every_x_rgb_frame + 1)
        self.proba_pause_when_running = proba_pause_when_running
        self.proba_pause_when_paused = proba_pause_when_paused
        self.scale_factor = scale_factor
        self.use_phased_arch = use_phased_arch
        self.baseline = baseline

    def __len__(self):
        return self.length

    def __getitem__(self, i):
        assert (i >= 0)
        assert (i < self.length)

        # generate a random seed here, that we will pass to the transform function
        # of each item, to make sure all the items in the sequence are transformed
        # in the same way
        seed = random.randint(0, 2 ** 32)

        # data augmentation: add random, virtual "pauses",
        # i.e. zero out random event tensors and repeat the last frame
        sequence = []

        # add the first element (i.e. do not start with a pause)
        k = 0
        j = i * self.step_size
        item = self.dataset.__getitem__(j, seed)
        sequence.append(item)

        paused = False
        for n in range(self.L - 1):

            # decide whether we should make a "pause" at this step
            # the probability of "pause" is conditioned on the previous state (to encourage long sequences)
            u = np.random.rand()
            if paused:
                probability_pause = self.proba_pause_when_paused
            else:
                probability_pause = self.proba_pause_when_running
            paused = (u < probability_pause)

            if paused:
                # add a tensor filled with zeros, paired with the last frame
                # do not increase the counter
                item = self.dataset.__getitem__(j + k, seed)
                item['events'].fill_(0.0)
                if 'flow' in item:
                    item['flow'].fill_(0.0)
                sequence.append(item)
            else:
                # normal case: append the next item to the list
                k += 1
                item = self.dataset.__getitem__(j + k, seed)
                sequence.append(item)

        # down sample data
        if self.scale_factor < 1.0:
            for data_items in sequence:
                for k, item in data_items.items():
                    if k != "times" and k != "batchlength_events":
                        item = item[None]
                        if "semantic" in k:
                            item = f.interpolate(item, scale_factor=self.scale_factor,
                                                 recompute_scale_factor=False)
                        else:
                            item = f.interpolate(item, scale_factor=self.scale_factor, mode='bilinear',
                                                 recompute_scale_factor=False, align_corners=False)
                        item = item[0]
                        data_items[k] = item
        return sequence


class SynchronizedFramesEventsDataset(Dataset):
    def __init__(self, base_folder, event_folder, depth_folder='frames', frame_folder='rgb', flow_folder='flow',
                 semantic_folder='semantic',
                 start_time=0.0, stop_time=0.0, clip_distance=100.0, every_x_rgb_frame=1,
                 transform=None,
                 normalize=True,
                 use_phased_arch=False,
                 baseline=False,
                 loss_composition=False,
                 reg_factor=5.7,
                 noise=None,
                 severity=None
                 ):

        self.base_folder = base_folder
        self.depth_folder = join(self.base_folder, depth_folder if depth_folder is not None else 'frames')
        self.frame_folder = join(self.base_folder, frame_folder if frame_folder is not None else 'rgb')
        self.flow_folder = join(self.base_folder, flow_folder if flow_folder is not None else 'flow')
        self.semantic_folder = join(self.base_folder, semantic_folder if semantic_folder is not None else 'semantic')
        self.transform = transform
        self.transform_2 = transform
        self.event_dataset = VoxelGridDataset(base_folder, event_folder,
                                              start_time, stop_time,
                                              transform=self.transform,
                                              normalize=normalize,
                                              noise=noise,
                                              severity=severity)

        self.eps = 1e-06
        self.clip_distance = clip_distance
        self.use_phased_arch = use_phased_arch
        self.every_x_rgb_frame = every_x_rgb_frame
        self.baseline = baseline
        self.loss_composition = loss_composition
        self.reg_factor = reg_factor

        self.test = False

        if "mvsec" in base_folder or "javi" in base_folder:
            self.use_mvsec = True
        else:
            self.use_mvsec = False

        # Load the stamp files
        self.stamps = np.loadtxt(
            join(self.depth_folder, 'timestamps.txt'))[:, 1]

        self.noise = noise
        self.severity = severity

        # shift the frame timestamps by the same amount as the event timestamps
        self.stamps -= self.event_dataset.initial_stamp

        # length = total number of datapoints, not equal to length of final dataset due to every_x_rgb_frame & step size
        self.length = len(self.event_dataset) - 1

        # Check that the frame timestamps are unique and sorted
        assert (np.alltrue(np.diff(self.stamps) > 0)
                ), "frame timestamps are not unique and monotonically increasing"

    def __len__(self):
        return self.length

    def __getitem__(self, i, seed=None):
        reg_factor = self.reg_factor
        assert (i >= 0)
        assert (i < (self.length // self.every_x_rgb_frame))
        item = {}

        def rgb2gray(rgb):
            return np.dot(rgb[..., :3], [0.2989, 0.5870, 0.1140]).astype(np.float32)

        def nan_helper(self, y):
            """Helper to handle indices and logical indices of NaNs.

            Input:
                - y, 1d numpy array with possible NaNs
            Output:
                - nans, logical indices of NaNs
                - index, a function, with signature indices= index(logical_indices),
                to convert logical indices of NaNs to 'equivalent' indices
            Example:
                >>> # linear interpolation of NaNs
                >>> nans, x= nan_helper(y)
                >>> y[nans]= np.interp(x(nans), x(~nans), y[~nans])
            """
            return np.isnan(y), lambda z: z.nonzero()[0]

        for k in range(0, self.every_x_rgb_frame):
            j = i * self.every_x_rgb_frame + k
            event_timestamp = self.event_dataset.get_stamp_at(j)
            (frame_idx, frame_timestamp) = first_element_greater_than(self.stamps, event_timestamp)
            assert (frame_idx >= 0)
            assert (frame_idx < len(self.stamps))
            assert (frame_timestamp - event_timestamp < 0.00001)

            if seed is None:
                # if no specific random seed was passed, generate our own.
                # otherwise, use the seed that was passed to us
                seed = random.randint(0, 2 ** 32)
            # Get the event tensor from the event dataset loader
            # Note that we pass the transform seed to ensure the same transform is
            if self.baseline != 'rgb':
                events = self.event_dataset.__getitem__(j, seed)

            # Load numpy depth ground truth frame
            if self.use_mvsec:
                frame = np.load(join(self.depth_folder, 'depth_{:010d}.npy'.format(frame_idx))).astype(np.float32)
            else:
                # path_depthframe = glob.glob(self.depth_folder + '/*_{:04d}_depth.npy'.format(frame_idx))
                # frame = np.load(path_depthframe[0]).astype(np.float32)
                frame = np.load(join(self.depth_folder, 'depth_{:010d}.npy'.format(frame_idx))).astype(np.float32)
            frame = torch.from_numpy(frame)
            if frame.ndim == 2:
                frame = frame.unsqueeze(0)

            if self.transform_2:
                random.seed(seed)
                frame = self.transform_2(frame)

            frame = torch.clamp(frame, 0.0, self.clip_distance)
            frame = frame / self.clip_distance
            frame = 1.0 + torch.log(frame) / reg_factor
            frame = torch.clamp(frame, 0, 1.0)
            # if test script is run, semantic segmentation is saved for later evaluation
            if self.test:
                segmask_path = glob.glob(self.semantic_folder + '/*_{:04d}_gt_labelIds.png'.format(frame_idx))
                seg_mask = cv2.imread(segmask_path[0])[:, :, 0].astype(np.float32)
                seg_mask = torch.tensor(seg_mask).unsqueeze(0)  # [1 x H x W]
                if self.transform_2:
                    random.seed(seed)
                    seg_mask = self.transform_2(seg_mask)

            if self.use_phased_arch:
                timestamp = torch.from_numpy(np.asarray([event_timestamp]).astype(np.float32))
                # timestamp = torch.tensor([event_timestamp])

            if not bool(self.baseline) or \
                    (self.baseline == 'e' and self.loss_composition == "image" and k < self.every_x_rgb_frame - 1):
                # for baseline e with sparse supervision, last event tensor of data package will be saved
                # in the "image" entry.
                item['events{}'.format(k)] = events['events']
                item['depth_events{}'.format(k)] = frame

                if self.test:
                    item['semantic_seg_{}'.format(k)] = seg_mask
                if self.use_phased_arch:
                    item['times_events{}'.format(k)] = timestamp

            if k == self.every_x_rgb_frame - 1:
                # Get RGB frame
                if self.frame_folder is not None:
                    try:
                        if self.use_mvsec:
                            rgb_frame = io.imread(join(self.frame_folder, 'frame_{:010d}.png'.format(frame_idx)),
                                                  as_gray=False).astype(np.float32)
                        else:
                            # path_rgbframe = glob.glob(self.frame_folder + '/*_{:04d}_image.png'.format(frame_idx))
                            # rgb_frame = io.imread(path_rgbframe[0], as_gray=False).astype(np.float32)
                            rgb_frame = io.imread(join(self.frame_folder, 'frame_{:010d}.png'.format(frame_idx)),
                                                  as_gray=False).astype(np.float32)
                        rgb_frame = apply_noise(
                            rgb_frame,
                            noise_type=self.noise,
                            severity=self.severity
                        )
                        if len(rgb_frame.shape) > 2:
                            if rgb_frame.shape[2] > 1:
                                gray_frame = rgb2gray(rgb_frame)  # [H x W]
                        else:
                            gray_frame = rgb_frame

                        gray_frame = gray_frame.astype(np.float32) / 255.0
                        gray_frame = np.expand_dims(gray_frame, axis=0)  # [1, H, W]

                        gray_frame = torch.from_numpy(gray_frame).float()

                        if self.transform_2:
                            random.seed(seed)
                            gray_frame = self.transform_2(gray_frame)


                    except FileNotFoundError as e:

                        raise FileNotFoundError(
                            f"Image not found at {join(self.frame_folder, 'frame_{:010d}.png'.format(frame_idx))}")

                item['events'] = events['events']
                item['image'] = gray_frame
                item['depth_image'] = frame

        return item

# class SynchronizedFramesEventsDataset(Dataset):
#     def __init__(self, base_folder, event_folder,
#                  depth_folder='frames',
#                  frame_folder='rgb',
#                  flow_folder='flow',
#                  semantic_folder='semantic',
#                  start_time=0.0, stop_time=0.0,
#                  clip_distance=100.0,
#                  every_x_rgb_frame=1,
#                  transform=None,
#                  normalize=True,
#                  use_phased_arch=False,
#                  baseline=False,
#                  loss_composition=False,
#                  reg_factor=5.7,
#                  noise=None,
#                  severity=None):
#
#         self.base_folder = base_folder
#         self.depth_folder = join(base_folder, depth_folder)
#         self.frame_folder = join(base_folder, frame_folder)
#         self.flow_folder = join(base_folder, flow_folder)
#         self.semantic_folder = join(base_folder, semantic_folder)
#
#         self.transform = transform
#         self.transform_2 = transform
#
#         self.noise = noise
#         self.severity = severity
#
#         # 你的 event dataset
#         self.event_dataset = VoxelGridDataset(
#             base_folder, event_folder,
#             start_time, stop_time,
#             transform=self.transform,
#             normalize=normalize,
#         )
#
#         self.clip_distance = clip_distance
#         self.every_x_rgb_frame = every_x_rgb_frame
#         self.use_phased_arch = use_phased_arch
#         self.baseline = baseline
#         self.loss_composition = loss_composition
#         self.reg_factor = reg_factor
#
#         self.test = False
#
#         self.use_mvsec = ("mvsec" in base_folder or "javi" in base_folder)
#
#         self.stamps = np.loadtxt(join(self.depth_folder, 'timestamps.txt'))[:, 1]
#         self.stamps -= self.event_dataset.initial_stamp
#
#         self.length = len(self.event_dataset) - 1
#
#         assert np.alltrue(np.diff(self.stamps) > 0)
#
#     def __len__(self):
#         return self.length
#
#     def rgb2gray(self, rgb):
#         return np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140]).astype(np.float32)
#
#     def __getitem__(self, i,seed=None):
#         assert i < (self.length // self.every_x_rgb_frame)
#
#         item = {}
#
#         seed = random.randint(0, 2**32)
#
#         for k in range(self.every_x_rgb_frame):
#             j = i * self.every_x_rgb_frame + k
#
#             event_timestamp = self.event_dataset.get_stamp_at(j)
#             frame_idx = np.searchsorted(self.stamps, event_timestamp)
#
#             # ===== events =====
#             if self.baseline != 'rgb':
#                 events = self.event_dataset.__getitem__(j, seed)
#
#             # ===== depth =====
#             frame = np.load(join(self.depth_folder, f'depth_{frame_idx:010d}.npy')).astype(np.float32)
#             frame = torch.from_numpy(frame).unsqueeze(0)
#
#             if self.transform_2:
#                 random.seed(seed)
#                 frame = self.transform_2(frame)
#
#             frame = torch.clamp(frame, 0.0, self.clip_distance)
#             frame = frame / self.clip_distance
#             frame = 1.0 + torch.log(frame + 1e-6) / self.reg_factor
#             frame = torch.clamp(frame, 0, 1.0)
#
#             if not bool(self.baseline):
#                 item[f'events{k}'] = events['events']
#                 item[f'depth_events{k}'] = frame
#
#             # ===== last frame → RGB =====
#             if k == self.every_x_rgb_frame - 1:
#
#                 rgb_frame = io.imread(
#                     join(self.frame_folder, f'frame_{frame_idx:010d}.png'),
#                     as_gray=False
#                 ).astype(np.uint8)
#
#                 # =========================
#                 # 🔥 加噪声（核心）
#                 # =========================
#                 rgb_frame = apply_noise(
#                     rgb_frame,
#                     noise_type=self.noise,
#                     severity=self.severity
#                 )
#
#                 # ===== 转灰度 =====
#                 if len(rgb_frame.shape) == 3:
#                     gray_frame = self.rgb2gray(rgb_frame)
#                 else:
#                     gray_frame = rgb_frame
#
#                 gray_frame = gray_frame / 255.0
#                 gray_frame = np.expand_dims(gray_frame, 0)
#                 gray_frame = torch.from_numpy(gray_frame)
#
#                 if self.transform_2:
#                     random.seed(seed)
#                     gray_frame = self.transform_2(gray_frame)
#
#                 item['events'] = events['events']
#                 item['image'] = gray_frame
#                 item['depth_image'] = frame
#
#         return item